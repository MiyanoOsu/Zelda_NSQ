#include "Listable.h"

Listable::Listable() {
}

Listable::~Listable() {
}

int Listable::compareTo(Listable* other) {
    return 0;
}
