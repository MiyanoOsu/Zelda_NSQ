#include "Loopable.h"

Loopable::Loopable() {
}

Loopable::~Loopable() {
}
