#include "Effect.h"

Effect::Effect() {
}

Effect::~Effect() {
}
